﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// CSC202 Alpha Moonbase Simulation
// Tony Baker 
// 7/26/ 2024
namespace CSC202_Alpha_Moonbase_Simulation
{
    public partial class FormMain2 : Form
    {
        public FormMain2(string from1)
        {
            InitializeComponent();
            TFF1Tb.Text = from1; // receives string from Form
            showAvailableRooms();
        }
        private void showAvailableRooms()
        {
            richTextBox2.Text = string.Empty;
            foreach (Area room in rooms)
            {
                if (!room.visible) continue;
                richTextBox2.Text += room.RoomName + Environment.NewLine;
            }

             
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormMain Form = new FormMain(textBox2.Text); // sends text to Form
            this.Hide();
            Form.Show();
        }

       

        private void button5_Click(object sender, EventArgs e) // This west button / Cafe
        {
            this.changeroom(0);
        }

        private void button4_Click(object sender, EventArgs e) // This is East button / Control Room
        {
            this.changeroom(1);
        }

        private void button3_Click(object sender, EventArgs e) // this is South button / S.Bedroom
        {
            this.changeroom(2);
        }

        private void button2_Click(object sender, EventArgs e) // This is North button / Labratory
        { // The code below will give an error to the user the number below is  6
       
            this.changeroom(3);
        }




        private Area[] rooms = // Room Descriptions

        {
            new Area ( "Cafe","A place for relaxation, food  drinks, music and it has a great view.", Properties.Resources.Cafeteria),
            new Area ( "Control","The control room is where activity, process and systems are monitored and directed.", Properties.Resources.controlroom),
            new Area ( "Bedroom","A celestial but conventional environment while bunking in a moonbase on the moon. The bedroom delivers a warmth and tranquility", Properties.Resources.bedroom),
            new Area ( "Labratory","The lab uses robots to perform samples of cultures that are found on the moon such as soil and small life forms .",Properties.Resources.RoboLAB),
            new Area ( "Simulator Room","A training simulator for astronauts to practice operating space vehicles",Properties.Resources.superneutral_art),
            new Area ( "Hospital","The hospital is for injuries and sickness.", Properties.Resources.hospital),
            new Area ( "Weapons", "Entance door to weapons bay.", Properties.Resources.weapons),
            new Area ( "Hallway", " The hallway is a hallwaty inside of tthe moonbase",Properties.Resources.hallway),
        };
        //  private Image[] backgroundImageS = { Properties.Resources.Cafeteria, Properties.Resources.controlroom, Properties.Resources.bedroom, Properties.Resources.RoboLAB, Properties.Resources.superneutral_art, Properties.Resources.hospital }; // Room Array
        private void changeroom(int index)                                            
              // conditional statements are place here
        {
            if (index < 0 || index >= rooms.Length)   // this is an if conditional


            {
                MessageBox.Show(index + " Is not a valid index!");  // Message box

            }
            else // this is an else statement
            {
                Area area = rooms[index];
                if (!area.visible) return;


                textBox1.Text = area.RoomName;  // this is a text box

                richTextBox1.Text = rooms[index].getDescription(); // allows to get private field

                 // try cach statement is below
                try
                {

                    this.BackgroundImage = rooms[index].RoomImage;
                }
                catch (Exception e) 
                { 
                  MessageBox.Show (e.ToString());  // shows the messagebox
                }

                showAvailableRooms();
            }
        }
          // this is label 3
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e) // Exhibit; VR room, land cruseir simulation
        {
            this.changeroom(4);
        }

        private void button7_Click(object sender, EventArgs e)  // button to infirmary
        {
            this.changeroom(5);
        }

        private void button8_Click(object sender, EventArgs e) // button to weapons 
        {
            this.changeroom(6);
            MessageBox.Show("You need a passcode!");
        }

        private void button9_Click(object sender, EventArgs e)  // button to hallway 
        {
            this.changeroom(7);
        }
    }
    // this is the class name and where the class starts
    public class Area
    {     // vars are declared below
        public string RoomName;
        private string Description;
        public Image RoomImage;
        public bool visible = true;

          // this constuctor assigns varibales based on the inputs
        public Area(string rn,string desc, Image img) 
        {
             this.RoomName = rn;
             this.Description = desc;
             this.RoomImage = img;
        }
       public void toggleRoom()
        {
            this.visible = !this.visible;// inverts current visible value 

        }

        public string getDescription()
        {
           return this.Description; // this gives a description
             



        }
        
         
    }

}
